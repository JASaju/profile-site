<?php

namespace App\Http\Middleware;

use App\Models\RequestActivity;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LogRequestActivity
{
    public function handle(Request $request, Closure $next)
    {
        return $next($request);
    }

    public function terminate(Request $request, Response $response): void
    {
        if ($request->is('media/*', 'file/*', 'robots.txt', 'sitemap.xml', 'google67ba2e4f33e282d3.html')) {
            return;
        }

        RequestActivity::create([
            'ip_address' => $request->ip(),
            'method' => substr($request->method(), 0, 10),
            'path' => substr('/' . ltrim($request->path(), '/'), 0, 2048),
            'status_code' => $response->getStatusCode(),
        ]);
    }
}
