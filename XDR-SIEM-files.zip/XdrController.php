<?php

namespace App\Http\Controllers;

use App\Models\RequestActivity;
use Illuminate\Http\Request;

class XdrController extends Controller
{
    public function benefits()
    {
        return view('admin.xdr.benefits', [
            'xdrBenefits' => [
                [
                    'category' => 'Threat detection',
                    'title' => 'See threats across the environment',
                    'description' => 'Combine endpoint, application, identity, and network signals to spot suspicious activity that a single alert may not explain.',
                    'value' => 'Earlier, broader threat awareness',
                ],
                [
                    'category' => 'Response',
                    'title' => 'Coordinate containment',
                    'description' => 'Give responders a shared workflow for validating incidents, assigning ownership, and coordinating containment and recovery actions.',
                    'value' => 'Faster, more consistent incident handling',
                ],
                [
                    'category' => 'Endpoint visibility',
                    'title' => 'Understand endpoint context',
                    'description' => 'Bring device identity, software posture, and endpoint activity into investigations to understand which assets and users may be affected.',
                    'value' => 'Clearer scope and impact',
                ],
                [
                    'category' => 'Threat intelligence',
                    'title' => 'Add context to indicators',
                    'description' => 'Compare observed indicators with curated threat intelligence to help analysts prioritize and investigate suspicious activity.',
                    'value' => 'Better-informed triage decisions',
                ],
                [
                    'category' => 'Automation',
                    'title' => 'Reduce repetitive response work',
                    'description' => 'Use approved playbooks for repeatable enrichment, notifications, and response steps, with analyst review for consequential actions.',
                    'value' => 'More time for high-value analysis',
                ],
                [
                    'category' => 'Investigation',
                    'title' => 'Connect activity into incidents',
                    'description' => 'Follow related events, entities, and response notes in one case to build a clearer timeline and preserve investigation context.',
                    'value' => 'Less fragmented investigations',
                ],
                [
                    'category' => 'Operational value',
                    'title' => 'Improve security team coordination',
                    'description' => 'Unify triage, ownership, and outcome tracking across security workflows so teams can learn from incidents and tune controls.',
                    'value' => 'More measurable, repeatable operations',
                ],
            ],
            'siemBenefits' => [
                [
                    'category' => 'Log correlation',
                    'title' => 'Connect events from many sources',
                    'description' => 'Normalize and correlate application, server, identity, and network logs to uncover relationships across otherwise separate systems.',
                    'value' => 'A joined-up view of activity',
                ],
                [
                    'category' => 'Threat detection',
                    'title' => 'Find patterns in security events',
                    'description' => 'Apply detection rules and behavioral analysis to collected events to highlight suspicious sequences and policy violations.',
                    'value' => 'More consistent alerting from logs',
                ],
                [
                    'category' => 'Compliance',
                    'title' => 'Support audit and evidence workflows',
                    'description' => 'Centralize relevant event records and documentable alert history to support internal reviews and applicable audit requirements.',
                    'value' => 'Easier evidence discovery and review',
                ],
                [
                    'category' => 'Threat intelligence',
                    'title' => 'Enrich events with external context',
                    'description' => 'Use maintained indicators and threat references to add context to log events and help distinguish routine activity from potential risk.',
                    'value' => 'More useful event prioritization',
                ],
                [
                    'category' => 'Investigation',
                    'title' => 'Search historical security activity',
                    'description' => 'Query a central event history to investigate incidents, establish timelines, and compare related activity over a chosen period.',
                    'value' => 'Quicker answers during incident review',
                ],
                [
                    'category' => 'Automation',
                    'title' => 'Standardize alert handling',
                    'description' => 'Route detections, enrich events, and notify owners using documented rules and repeatable workflows, with human approval where needed.',
                    'value' => 'Less manual alert administration',
                ],
                [
                    'category' => 'Operational value',
                    'title' => 'Make security activity measurable',
                    'description' => 'Use consistent event and alert records to identify recurring issues, tune monitoring, and communicate operational trends.',
                    'value' => 'Better-informed security planning',
                ],
            ],
        ]);
    }

    public function dashboard()
    {
        $today = now()->startOfDay();
        $lastDay = now()->subDay();

        return view('admin.xdr.dashboard', [
            'requestsToday' => RequestActivity::where('created_at', '>=', $today)->count(),
            'uniqueIps' => RequestActivity::where('created_at', '>=', $lastDay)
                ->whereNotNull('ip_address')
                ->distinct('ip_address')
                ->count('ip_address'),
            'errorRequests' => RequestActivity::where('created_at', '>=', $lastDay)
                ->where('status_code', '>=', 400)
                ->count(),
            'recentRequests' => RequestActivity::latest()->limit(8)->get(),
            'alerts' => [
                [
                    'severity' => 'Critical',
                    'title' => 'Repeated authentication failures',
                    'detail' => 'Multiple failed sign-in attempts detected',
                    'ip' => '198.51.100.24',
                    'time' => now()->subMinutes(4),
                ],
                [
                    'severity' => 'High',
                    'title' => 'Unusual request pattern',
                    'detail' => 'Automated path discovery pattern flagged',
                    'ip' => '203.0.113.17',
                    'time' => now()->subMinutes(18),
                ],
                [
                    'severity' => 'Medium',
                    'title' => 'Web policy event',
                    'detail' => 'Request returned a client error response',
                    'ip' => '192.0.2.42',
                    'time' => now()->subMinutes(36),
                ],
            ],
            'agents' => [
                ['name' => 'PROFILE-WEB-01', 'platform' => 'Laravel web node', 'state' => 'Online'],
                ['name' => 'PROFILE-DB-01', 'platform' => 'Database node', 'state' => 'Online'],
                ['name' => 'EDGE-GATEWAY', 'platform' => 'Reverse proxy', 'state' => 'Online'],
            ],
        ]);
    }

    public function requests(Request $request)
    {
        $filters = $request->validate([
            'q' => ['nullable', 'string', 'max:255'],
            'status' => ['nullable', 'integer', 'between:100,599'],
        ]);
        $query = RequestActivity::query()->latest();

        if (!empty($filters['q'])) {
            $term = $filters['q'];
            $query->where(function ($builder) use ($term) {
                $builder->where('ip_address', 'like', '%' . $term . '%')
                    ->orWhere('path', 'like', '%' . $term . '%')
                    ->orWhere('method', 'like', '%' . $term . '%');
            });
        }

        if (!empty($filters['status'])) {
            $query->where('status_code', (int) $filters['status']);
        }

        return view('admin.xdr.requests', [
            'requests' => $query->paginate(25)->withQueryString(),
            'totalRequests' => RequestActivity::count(),
            'uniqueIps' => RequestActivity::whereNotNull('ip_address')->distinct('ip_address')->count('ip_address'),
        ]);
    }
}
